from abc import ABC, abstractmethod
from typing import Mapping, Optional, final
import requests
import logging

from zcp_py_plugin.phi import Phi
from zcp_py_plugin.request import Request

"""Base class for all plugins
"""


class Plugin(ABC):
    def __init__(self, vendor: str, name_by_endpoint: Mapping[str, str], request: Request):
        self.vendor = vendor
        self.name_by_endpoint = name_by_endpoint
        self.request = request
        logging.info("Request: %s", request)

    @abstractmethod
    def do(self) -> None:
        """ This is called by the PluginClient in the beginning.
        This is run on a separate thread
        """
        pass

    @final
    def get_phi(self) -> Optional[Phi]:
        if self.request.phi:
            r = requests.get(self.request.phi)
            r.raise_for_status()
            return Phi.of().from_dict(r.json()).build()
        else:
            return None

