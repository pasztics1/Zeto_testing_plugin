import os
from abc import abstractmethod
from struct import unpack_from
from typing import final, Optional, Dict, List, BinaryIO

from zcp_py_plugin.file_plugin import FilePlugin
from zcp_py_plugin.meta import Meta
from zcp_py_plugin.phi import Phi
from zcp_py_plugin.request import Request

"""Base class for all analysis plugins
"""


def _fromfile(file: BinaryIO, count: int) -> list[float]:
    buffer = file.read(count*4)
    ret: list[float] = []
    for i in range(count):
        ret.append(unpack_from('>f', buffer, offset=i*4)[0])
    return ret


class AnalysisPlugin(FilePlugin):
    def __init__(self, vendor: str, name_by_endpoint: dict[str, str], request: Request):
        super().__init__(vendor, name_by_endpoint, request)

    def _handle_http_source(self, meta: Meta, phi: Optional[Phi]):
        source_file = self._get_source()
        try:
            self._feed(source_file, meta, phi)
        finally:
            os.unlink(source_file)

    @final
    def _collect_samples_by_channel(self, inp: list[float], chunk_sample_count: int) -> Dict[str, list[float]]:
        channel_count = len(self.request.meta.channels)
        read_sample_count = len(inp)/channel_count
        if read_sample_count != chunk_sample_count:
            raise ValueError(f"{read_sample_count} != {chunk_sample_count}")

        reshaped_float_array: list[list[float]] = list()
        for i in range(channel_count):
            channel_data: List[float] = list()
            for j in range(chunk_sample_count):
                channel_data.append(inp[j * channel_count + i])
            reshaped_float_array.append(channel_data)

        data: Dict[str, list[float]] = dict()
        for (channel, chunk) in zip(self.request.meta.channels, reshaped_float_array):
            if channel in data:
                data[channel].append(chunk)
            else:
                data[channel] = chunk
        return data

    @final
    def _feed(self, file_name: str, meta: Meta, phi: Optional[Phi]):
        channel_count = len(self.request.meta.channels)
        offset = 0
        remaining_sample_count = self.request.meta.sample_count
        with open(file_name, 'rb') as file:
            while remaining_sample_count > 0:
                chunk_sample_count = min(int(600 * self.request.meta.sample_rate), remaining_sample_count)
                chunk = _fromfile(file, count=chunk_sample_count*channel_count)
                data = self._collect_samples_by_channel(chunk, chunk_sample_count)
                self.process(meta, phi, data)
                offset += chunk_sample_count*channel_count
                remaining_sample_count -= chunk_sample_count

    @final
    def go(self) -> None:
        phi = self.get_phi()
        self.progress(0)
        self.start(self.request.meta, phi)
        if self.request.source.startswith('wss://'):
            raise NotImplementedError("Analysis Plugins currently don't support ws sources")
        elif self.request.source.startswith('https://') or self.request.source.startswith('http://'):
            self._handle_http_source(self.request.meta, phi)
        else:
            raise NotImplementedError(f"Analysis Plugins currently don't support source: {self.request.source}")
        self.finish(self.request.meta, phi)
        self.progress(100)

    @abstractmethod
    def start(self, meta: Meta, phi: Optional[Phi]) -> None:
        """Init the plugin
        :param meta: metadata of the data
        :param phi: Protected Health Information
        :type phi: Phi
        """
        pass

    @abstractmethod
    def process(self, meta: Meta, phi: Optional[Phi], data: Dict[str, list[float]]) -> None:
        """Process the samples of 10 minutes range
        :param meta: metadata of the data
        :param phi: optional Protected Health Information
        :param data: mapping of channel, float array of samples
        :type data: Dict [channel symbol: float array]
        """
        pass

    @abstractmethod
    def finish(self, meta: Meta, phi: Optional[Phi]) -> None:
        """Called when capture is finished.
        Plugin shall finish the calculation and generate the final result
        :param meta: metadata of the data
        :param phi: optional Protected Health Information
        """
        pass
