from __future__ import annotations
from typing import Any, Self, Optional, Dict
from dataclasses import dataclass
from frozendict import frozendict

from zcp_py_plugin.capture_status import CaptureStatus


class MetaBuilder:
    def __init__(self):
        self._channels: Optional[tuple[str, ...]] = None
        self._references: Optional[tuple[str, ...]] = None
        self._sample_rate: Optional[float] = None
        self._sample_count: Optional[int] = None
        self._padding_count: Optional[int] = None

        self._capture_id: Optional[str] = None
        self._device_symbol: Optional[str] = None
        self._capture_symbol: Optional[str] = None
        self._user_recording: Optional[str] = None
        self._capture_start_time: Optional[str] = None
        self._capture_start_time_display: Optional[str] = None
        self._capture_duration: Optional[int] = None
        self._capture_duration_display: Optional[str] = None
        self._capture_status: Optional[CaptureStatus] = None
        self._capture_title: Optional[str] = None
        self._parameters: Optional[Dict[str, Any]] = None
        self._organization_symbol: Optional[str] = None
        self._organization: Optional[str] = None
        self._organization_logo: Optional[str] = None
        self._organization_letterhead: Optional[str] = None
        self._user_timezone: Optional[str] = None
        self._user_locale: Optional[str] = None
        self._report_local_code: Optional[str] = None

    def from_dict(self, dict_object: dict[str, Any]) -> Self:
        return self.channels(dict_object['channels']) \
            .references(dict_object['references']) \
            .sample_rate(dict_object['samplerate']) \
            .sample_count(dict_object['samplecount']) \
            .padding_count(dict_object['paddingcount']) \
            .capture_id(dict_object['captureId']) \
            .device_symbol(dict_object['deviceSymbol']) \
            .capture_symbol(dict_object['captureSymbol']) \
            .user_recording(dict_object['userRecording']) \
            .capture_start_time(dict_object['captureStartTime']) \
            .capture_start_time_display(dict_object['captureStartTimeDisplay']) \
            .capture_duration(dict_object['captureDuration']) \
            .capture_duration_display(dict_object['captureDurationDisplay']) \
            .capture_status(dict_object['captureStatus']) \
            .capture_title(dict_object['captureTitle']) \
            .parameters(dict_object['parameters']) \
            .organization_symbol(dict_object['organizationSymbol']) \
            .organization(dict_object['organization']) \
            .organization_logo(dict_object['organizationLogo']) \
            .organization_letterhead(dict_object['organizationLetterhead']) \
            .user_timezone(dict_object['userTimezone']) \
            .user_locale(dict_object['userLocale']) \
            .report_local_code(dict_object['reportLocalCode'])

    def channels(self, channels: str | tuple[str]) -> Self:
        if isinstance(channels, str):
            self._channels = channels.split(',')
        else:
            self._channels = channels
        return self

    def references(self, references: str | tuple[str]) -> Self:
        if isinstance(references, str):
            self._references = references.split(',')
        else:
            self._references = references
        return self

    def sample_rate(self, sample_rate: float) -> Self:
        self._sample_rate = sample_rate
        return self

    def sample_count(self, sample_count: float) -> Self:
        self._sample_count = sample_count
        return self

    def padding_count(self, padding_count: float) -> Self:
        self._padding_count = padding_count
        return self

    def capture_id(self, capture_id: str) -> Self:
        self._capture_id = capture_id
        return self

    def device_symbol(self, device_symbol: str) -> Self:
        self._device_symbol = device_symbol
        return self

    def capture_symbol(self, capture_symbol: str) -> Self:
        self._capture_symbol = capture_symbol
        return self

    def user_recording(self, user_recording: str) -> Self:
        self._user_recording = user_recording
        return self

    def capture_start_time(self, capture_start_time: str) -> Self:
        self._capture_start_time = capture_start_time
        return self

    def capture_start_time_display(self, capture_start_time_display: str) -> Self:
        self._capture_start_time_display = capture_start_time_display
        return self

    def capture_duration(self, capture_duration: int) -> Self:
        self._capture_duration = capture_duration
        return self

    def capture_duration_display(self, capture_duration_display: str) -> Self:
        self._capture_duration_display = capture_duration_display
        return self

    def capture_status(self, capture_status: str | CaptureStatus) -> Self:
        if isinstance(capture_status, str):
            self._capture_status = CaptureStatus.get_from_name(capture_status)
        else:
            self._capture_status = capture_status
        return self

    def capture_title(self, capture_title: str) -> Self:
        self._capture_title = capture_title
        return self

    def parameters(self, parameters: Dict[str, Any]) -> Self:
        self._parameters = frozendict(parameters)
        return self

    def organization_symbol(self, organization_symbol: str) -> Self:
        self._organization_symbol = organization_symbol
        return self

    def organization(self, organization: str) -> Self:
        self._organization = organization
        return self

    def organization_logo(self, organization_logo: str) -> Self:
        self._organization_logo = organization_logo
        return self

    def organization_letterhead(self, organization_letterhead: str) -> Self:
        self._organization_letterhead = organization_letterhead
        return self

    def user_timezone(self, user_timezone: str) -> Self:
        self._user_timezone = user_timezone
        return self

    def user_locale(self, user_locale: str) -> Self:
        self._user_locale = user_locale
        return self

    def report_local_code(self, report_local_code: str) -> Self:
        self._report_local_code = report_local_code
        return self

    def build(self) -> Meta:
        return Meta(
            channels=self._channels,
            references=self._references,
            sample_rate=self._sample_rate,
            sample_count=self._sample_count,
            padding_count=self._padding_count,
            capture_id=self._capture_id,
            device_symbol=self._device_symbol,
            capture_symbol=self._capture_symbol,
            user_recording=self._user_recording,
            capture_start_time=self._capture_start_time,
            capture_start_time_display=self._capture_start_time_display,
            capture_duration=self._capture_duration,
            capture_duration_display=self._capture_duration_display,
            capture_status=self._capture_status,
            capture_title=self._capture_title,
            parameters=self._parameters,
            organization_symbol=self._organization_symbol,
            organization=self._organization,
            organization_logo=self._organization_logo,
            organization_letterhead=self._organization_letterhead,
            user_timezone=self._user_timezone,
            user_locale=self._user_locale,
            report_local_code=self._report_local_code
        )


@dataclass(frozen=True)
class Meta:
    channels: tuple[str, ...]
    references: tuple[str, ...]
    sample_rate: float
    sample_count: int
    padding_count: int
    capture_id: str
    device_symbol: str
    capture_symbol: str
    user_recording: str
    capture_start_time: str
    capture_start_time_display: str
    capture_duration: int
    capture_duration_display: str
    capture_status: CaptureStatus
    capture_title: str
    parameters: Dict[str, Any]
    organization_symbol: str
    organization: str
    organization_logo: str
    organization_letterhead: str
    user_timezone: str
    user_locale: str
    report_local_code: str

    @classmethod
    def of(cls) -> MetaBuilder:
        return MetaBuilder()


if __name__ == '__main__':
    m = Meta.of()\
        .channels('fp1,fp2,f7,f3')\
        .references('cz')\
        .sample_rate(5)\
        .sample_count(1500)\
        .padding_count(500)\
        .capture_id('CXprCSPiynRsShnSFgsasG')\
        .capture_symbol('ZE-970-015-116')\
        .user_recording('Robert Soti')\
        .capture_start_time('2023-11-06T03:02:52.960500933-05:00[America/New_York]')\
        .capture_start_time_display('3:02:52 AM')\
        .capture_duration(1218000)\
        .capture_duration_display('20 minutes,18 seconds')\
        .capture_status('IMPORTED')\
        .capture_title('DO0815199')\
        .parameters({
            "captures": ["Cxxxxx", "Cyyyyy", "Czzz"],
            "input": "sleep eeg"
        })\
        .organization_symbol('SAMA')\
        .organization('Sama Therapetutics')\
        .organization_logo('https://resource.zetoserver.com/organization/OXojUuA0HF8zY2DnTf1EKb.png?v=2WKbQsRNIuUQb6XjeP3SAoRAA1_Sw70o')\
        .organization_letterhead('Zeto, Inc. 4701, Patrick Henry Dr., Building #25, Santa Clara, CA 95054, USA.')\
        .user_timezone('timezone')\
        .user_locale('en-US')\
        .report_local_code('ZR-123-456-245')\
        .build()
    print(m)
