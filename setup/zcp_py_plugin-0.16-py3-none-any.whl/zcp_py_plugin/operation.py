from enum import Enum, auto


class Operation(Enum):
    transform = auto()
    annotation = auto()
    dock = auto()
    trendings = auto()
    backdrop = auto()
    statusbar = auto()
    datasink = auto()
    cqsink = auto()
    measuresingle = auto()
    measuremulti = auto()
    pdf = auto()

