from enum import Enum, auto


class PluginResultType(Enum):
    @classmethod
    def get_from_name(cls, value):
        for m, mm in PluginResultType.__members__.items():
            if m == value:
                return mm
        raise ValueError(f'PluginResultType operation type: {value}')

    ANNOTATION = auto()
    DOCK = auto()
    TRENDINGSLEFT = auto()
    TRENDINGSCENTER = auto()
    TRENDINGSRIGHT = auto()
    TRENDINGSMETA = auto()
    STATUSBAR = auto()
    BACKDROP = auto()
    PDF = auto()
