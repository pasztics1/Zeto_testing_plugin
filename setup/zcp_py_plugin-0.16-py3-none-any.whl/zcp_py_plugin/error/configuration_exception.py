class ConfigurationException(Exception):
    """Represent expected exception when plugin cannot be started due to a configuration error
    """

    def __init__(self, message=None):
        super(Exception, self).__init__(message)
