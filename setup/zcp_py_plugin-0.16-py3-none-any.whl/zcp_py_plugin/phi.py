from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Any, Self

from zcp_py_plugin.gender import Gender
from zcp_py_plugin.handedness import Handedness


class PhiBuilder:
    def __init__(self):
        self._name: Optional[str] = None
        self._birth_date: Optional[str] = None
        self._age: Optional[float] = None
        self._ssn: Optional[str] = None
        self._mrn: Optional[str] = None
        self._phone: Optional[str] = None
        self._email: Optional[str] = None
        self._address: Optional[str] = None
        self._city: Optional[str] = None
        self._zip: Optional[str] = None
        self._state: Optional[str] = None
        self._country: Optional[str] = None
        self._gender: Optional[Gender] = None
        self._handedness: Optional[Handedness] = None
        self._weight: Optional[float] = None
        self._height: Optional[float] = None
        self._bmi: Optional[float] = None

        self._medication: Optional[str] = None
        self._history: Optional[str] = None
        self._sedation: Optional[str] = None
        self._activation: Optional[str] = None
        self._indication: Optional[str] = None
        self._conditions_of_recording: Optional[str] = None

    def name(self, name: str) -> Self:
        self._name = name
        return self

    def birth_date(self, birth_date: str) -> Self:
        self._birth_date = birth_date
        return self

    def age(self, age: float) -> Self:
        self._age = age
        return self

    def ssn(self, ssn: str) -> Self:
        self._ssn = ssn
        return self

    def mrn(self, mrn: str) -> Self:
        self._mrn = mrn
        return self

    def phone(self, phone: str) -> Self:
        self._phone = phone
        return self

    def email(self, email: str) -> Self:
        self._email = email
        return self

    def address(self, address: str) -> Self:
        self._address = address
        return self

    def city(self, city: str) -> Self:
        self._city = city
        return self

    def zip(self, _zip: str) -> Self:
        self._zip = _zip
        return self

    def state(self, state: str) -> Self:
        self._state = state
        return self

    def country(self, country: str) -> Self:
        self._country = country
        return self

    def gender(self, gender: Gender) -> Self:
        self._gender = gender
        return self

    def handedness(self, handedness: Handedness) -> Self:
        self._handedness = handedness
        return self

    def weight(self, weight: float) -> Self:
        self._weight = weight
        return self

    def height(self, height: float) -> Self:
        self._height = height
        return self

    def bmi(self, bmi: float) -> Self:
        self._bmi = bmi
        return self

    def medication(self, medication: str) -> Self:
        self._medication = medication
        return self

    def history(self, history: str) -> Self:
        self._history = history
        return self

    def sedation(self, sedation: str) -> Self:
        self._sedation = sedation
        return self

    def activation(self, activation: str) -> Self:
        self._activation = activation
        return self

    def indication(self, indication: str) -> Self:
        self._indication = indication
        return self

    def conditions_of_recording(self, conditions_of_recording: str) -> Self:
        self._conditions_of_recording = conditions_of_recording
        return self

    def build(self) -> Phi:
        return Phi(
            name=self._name,
            birth_date=self._birth_date,
            age=self._age,
            ssn=self._ssn,
            mrn=self._mrn,
            phone=self._phone,
            email=self._email,
            address=self._address,
            city=self._city,
            zip=self._zip,
            state=self._state,
            country=self._country,
            gender=self._gender,
            handedness=self._handedness,
            weight=self._weight,
            height=self._height,
            bmi=self._bmi,
            medication=self._medication,
            history=self._history,
            sedation=self._sedation,
            activation=self._activation,
            indication=self._indication,
            conditions_of_recording=self._conditions_of_recording
        )

    def from_dict(self, dict_object: dict[str, Any]) -> Self:
        return self.birth_date(dict_object.get("birthDate")) \
            .name(dict_object.get("name")) \
            .age(dict_object.get("age")) \
            .ssn(dict_object.get("ssn")) \
            .mrn(dict_object.get("mrn")) \
            .phone(dict_object.get("phone")) \
            .email(dict_object.get("email")) \
            .address(dict_object.get("address")) \
            .city(dict_object.get("city")) \
            .zip(dict_object.get("zip")) \
            .state(dict_object.get("state")) \
            .country(dict_object.get("country")) \
            .gender(Gender.get_from_name(dict_object.get("gender"))) \
            .handedness(Handedness.get_from_name(dict_object.get("handedness"))) \
            .weight(dict_object.get("weight")) \
            .height(dict_object.get("height")) \
            .bmi(dict_object.get("bmi")) \
            .medication(dict_object.get("medication")) \
            .history(dict_object.get("history")) \
            .sedation(dict_object.get("sedation")) \
            .activation(dict_object.get("activation")) \
            .indication(dict_object.get("indication")) \
            .conditions_of_recording(dict_object.get("conditionsOfRecording"))


@dataclass(frozen=True)
class Phi:
    @classmethod
    def of(cls) -> PhiBuilder:
        return PhiBuilder()

    name: Optional[str]
    birth_date: Optional[str]
    age: Optional[float]
    ssn: Optional[str]
    mrn: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    address: Optional[str]
    city: Optional[str]
    zip: Optional[str]
    state: Optional[str]
    country: Optional[str]
    gender: Optional[Gender]
    handedness: Optional[Handedness]
    weight: Optional[float]  # in kg
    height: Optional[float]  # in cm
    bmi: Optional[float]

    medication: Optional[str]
    history: Optional[str]
    sedation: Optional[str]
    activation: Optional[str]
    indication: Optional[str]
    conditions_of_recording: Optional[str]
