from __future__ import annotations
from typing import Optional
from enum import Enum, auto


class Handedness(Enum):
    @classmethod
    def get_from_name(cls, value: Optional[str]) -> Optional[Handedness]:
        if value:
            for m, mm in Handedness.__members__.items():
                if m == value:
                    return mm
            raise ValueError(f'Unknown Handedness type: {value}')
        else:
            return None

    LEFT = auto()
    RIGHT = auto()
    UNSET = auto()
