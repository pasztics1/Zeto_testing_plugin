from enum import Enum, auto


class Mode(Enum):
    batch = auto()
    interpret = auto()
    realtime = auto()
