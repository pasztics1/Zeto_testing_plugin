from typing import Optional, final
from abc import abstractmethod
from zcp_py_plugin.file_plugin import FilePlugin
from zcp_py_plugin.meta import Meta
from zcp_py_plugin.phi import Phi


"""Base class for all report plugins
"""


class ReportPlugin(FilePlugin):
    @abstractmethod
    def process(self, meta: Meta, phi: Optional[Phi]) -> None:
        """
        Process the request
        :param meta: metadata of the data
        :param phi: optional Protected Health Information
        """
        pass

    @final
    def go(self) -> None:
        phi = self.get_phi()
        self.progress(0)
        self.process(self.request.meta, phi)
        self.progress(100)
