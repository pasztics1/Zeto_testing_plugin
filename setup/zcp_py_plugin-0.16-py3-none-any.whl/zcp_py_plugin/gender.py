from __future__ import annotations
from typing import Optional
from enum import Enum, auto


class Gender(Enum):
    @classmethod
    def get_from_name(cls, value: Optional[str]) -> Optional[Gender]:
        if value:
            for m, mm in Gender.__members__.items():
                if m == value:
                    return mm
            raise ValueError(f'PluginResultType operation type: {value}')
        else:
            return None

    MALE = auto()
    FEMALE = auto()
    UNSET = auto()

