from enum import Enum, auto


class MarkerFormat(Enum):
    @classmethod
    def get_from_name(cls, value):
        for m, mm in MarkerFormat.__members__.items():
            if m == value:
                return mm
        raise ValueError(f'MarkerFormat operation type: {value}')

    ZMRK = auto()
    JSON = auto()
    CSV = auto()
