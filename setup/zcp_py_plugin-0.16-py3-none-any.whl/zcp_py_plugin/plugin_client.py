from __future__ import annotations

import logging
import os
import sys
from typing import Optional, Self, Any, Sequence, Mapping, final
import json
import base64
import traceback
import time
import contextlib

import requests
from websocket import WebSocketApp

import threading
from threading import Lock

from frozendict import frozendict
import boto3
from botocore.credentials import Credentials
from botocore.awsrequest import AWSRequest
from botocore.auth import SigV4QueryAuth
from iam_rolesanywhere_session import IAMRolesAnywhereSession

from zcp_py_plugin.mode import Mode
from zcp_py_plugin.plugin import Plugin
from zcp_py_plugin.source import Source
from zcp_py_plugin.operation import Operation
from zcp_py_plugin.request import Request
from zcp_py_plugin.error.configuration_exception import ConfigurationException


INITIAL_BACKOFF = 5


def _add_field_if_exists (key: str, value: Optional[Any], dict_object: dict[str, Any]):
    if value:
        dict_object.update({
            key: value
        })


def get_endpoint_from_name(name: str):
    return name.strip().replace(' ', '').lower()


def _report_error(ex: Exception, request: Request) -> None:
    try:
        requests.post(
            url=request.progress,
            json={
                "status": "ERROR",
                "message": str(ex),
                "details": ''.join(traceback.TracebackException.from_exception(ex).format())
            }
        )
    except Exception:
        logging.exception('Failed to report error')
    raise ex


class PluginClientBuilder:
    def __init__(self):
        self._vendor: Optional[str] = None
        self._name_by_endpoint: dict[str, str] = dict()
        self._version: str = '0.0.0'
        self._args = sys.argv[1:]
        self._is_fda: bool = False
        self._mode: Mode = Mode.batch
        self._plugin: Optional[type[Plugin]] = None
        self._server: str = 'api.zetoserver.com'
        self._server_region: str = 'us-east-1'
        self._auth_string: Optional[str] = None
        self._source: Source = Source.original
        self._operation: Operation = Operation.datasink
        self._description: Optional[str] = None
        self._icon: Optional[str] = None
        self._input_name: Optional[str] = None
        self._input_parameters: Optional[dict[str, Any]] = None

    def vendor(self, vendor: str) -> Self:
        self._vendor = vendor
        return self

    def name(self, name: str, endpoint: Optional[str] = None) -> Self:
        _endpoint = endpoint if endpoint else get_endpoint_from_name(name)
        self._name_by_endpoint[_endpoint] = name
        return self

    def version(self, version: str) -> Self:
        self._version = version
        return self

    def is_fda(self, is_fda: bool) -> Self:
        self._is_fda = is_fda
        return self

    def mode_interpret(self) -> Self:
        self._mode = Mode.interpret
        return self

    def mode_batch(self) -> Self:
        self._mode = Mode.batch
        return self

    def mode_realtime(self) -> Self:
        self._mode = Mode.realtime
        return self

    def source_original(self) -> Self:
        self._source = Source.original
        return self

    def source_processed(self) -> Self:
        self._source = Source.processed
        return self

    def operation_transform(self) -> Self:
        self._operation = Operation.transform
        return self

    def operation_annotation(self) -> Self:
        self._operation = Operation.annotation
        return self

    def operation_dock(self) -> Self:
        self._operation = Operation.dock
        return self

    def operation_trendings(self) -> Self:
        self._operation = Operation.trendings
        return self

    def operation_backdrop(self) -> Self:
        self._operation = Operation.backdrop
        return self

    def operation_statusbar(self) -> Self:
        self._operation = Operation.statusbar
        return self

    def operation_datasink(self) -> Self:
        self._operation = Operation.datasink
        return self

    def operation_cqsink(self) -> Self:
        self._operation = Operation.cqsink
        return self

    def operation_measuresingle(self) -> Self:
        self._operation = Operation.measuresingle
        return self

    def operation_measuremulti(self) -> Self:
        self._operation = Operation.measuremulti
        return self

    def operation_pdf(self) -> Self:
        self._operation = Operation.pdf
        return self

    def plugin(self, plugin: type[Plugin]) -> Self:
        self._plugin = plugin
        return self

    def server(self, server: str) -> Self:
        self._server = server
        return self

    def server_region(self, server_region: str) -> Self:
        self._server_region = server_region
        return self

    def auth_string(self, auth_string: str) -> Self:
        self._auth_string = auth_string
        return self

    def description(self, description: str) -> Self:
        self._description = description
        return self

    def icon(self, icon: str) -> Self:
        self._icon = icon
        return self

    def inputs(self, input_name: str, input_parameters: Optional[dict[str, Any]] = None) -> Self:
        self._input_name = input_name
        self._input_parameters = input_parameters
        return self

    def build(self) -> PluginClient:

        return PluginClient(
            auth_string=self._auth_string,
            server=os.environ['server'] if 'server' in os.environ else self._server,
            server_region=os.environ['server_region'] if 'server_region' in os.environ else self._server_region,
            plugin=self._plugin,
            mode=self._mode,
            is_fda=self._is_fda,
            args=self._args,
            version=self._version,
            name_by_endpoint=self._name_by_endpoint,
            vendor=self._vendor,
            source=self._source,
            operation=self._operation,
            description=self._description,
            icon=self._icon,
            input_name=self._input_name,
            input_parameters=self._input_parameters
        )


@final
class PluginClient:

    @classmethod
    def of(cls) -> PluginClientBuilder:
        return PluginClientBuilder()

    def __init__(self,
                 auth_string: str, server: str, server_region: str, plugin: type[Plugin],
                 mode: Mode, is_fda: bool, args: Sequence[str], version: str,
                 name_by_endpoint: Mapping[str, str], vendor: str,
                 source: Source, operation: Operation, description: str, icon: str,
                 input_name: str, input_parameters: Optional[dict[str, Any]]):
        self._auth_string = auth_string
        self._server = server
        self._server_region = server_region
        self._plugin = plugin
        self._mode = mode
        self._is_fda = is_fda
        self._args = args
        self._version = version
        self._name_by_endpoint = frozendict(name_by_endpoint)
        self._vendor = vendor
        self._source = source
        self._operation = operation
        self._description = description
        self._icon = icon
        self._input_name = input_name
        self._input_parameters = frozendict(input_parameters) if input_parameters else None
        self._lock = Lock()
        self._backoff = INITIAL_BACKOFF
        self._resend_ident = False
        self._stop = False
        if self._args:
            # handle the request, i.e. aws batch job
            request = Request.of().message(self._args[0]).build()
            try:
                plugin = self._plugin(self._vendor, self._name_by_endpoint, request)
                plugin.do()
            except Exception as ex:
                _report_error(ex, request)
        else:
            # WS connection and handling methods
            self._start_ws()

    def _start_ws(self):
        def on_open(ws_app: WebSocketApp):
            # send ident
            logging.info('Connected')
            self._set_backoff(INITIAL_BACKOFF)  # reset backoff
            logging.info("Sending ident")
            _ident = self._ident()
            ws_app.send(_ident)
            logging.info(f"Sent ident: {_ident}")

        def on_error(_ws_app: WebSocketApp, ex: Exception):
            logging.error('Ws error occurred', exc_info=ex)
            if isinstance(ex, KeyboardInterrupt) or isinstance(ex, SystemExit):
                self._set_stop()

        def on_message(ws_app: WebSocketApp, message: str):
            # handle incoming requests
            mes = json.loads(message)
            message_type = mes["message"]
            if message_type == "heartbeat":
                # handle heartbeat
                ws_app.send('{"message":"heartbeat"}')
            elif message_type in [f"request/{self._vendor}/{endpoint}" for endpoint in self._name_by_endpoint]:
                req = Request.of().from_dict(mes).build()
                try:
                    plug = self._plugin(self._vendor, self._name_by_endpoint, req)
                except Exception as e:
                    _report_error(e, req)

                def run():
                    try:
                        plug.do()
                    except Exception as error:
                        _report_error(error, req)

                # process the request on different thread
                threading.Thread(target=run).start()
            elif message_type == "error":
                logging.error(f"Error received: {message}")
                logging.info("Resending ident after a while.")
                # error means ident was not accepted
                self._set_resend_ident(True)

            else:
                logging.error(f"Unexpected message received: {message}")

        def on_close(_ws_app: WebSocketApp, close_status_code: Optional[int], close_msg: Optional[str]):
            logging.info(f"Closed ws connection. Status code: {close_status_code}, close message: {close_msg}")

        def on_ping(_ws: WebSocketApp, message: str):
            logging.info(f"Received ping: {message}")

        def on_pong(ws_app: WebSocketApp, _message: str):
            if self._get_resend_ident():
                logging.info("Resending ident")
                self._set_resend_ident(False)
                ws_app.send(self._ident())

        while not self._is_stop():
            try:
                with contextlib.closing(WebSocketApp(
                        self._get_signed_connect_url(),
                        on_open=on_open,
                        on_message=on_message,
                        on_close=on_close,
                        on_error=on_error,
                        on_ping=on_ping,
                        on_pong=on_pong)) as ws:
                    ws.run_forever(ping_interval=60, ping_timeout=10)
                    logging.info("Run forever ended.")
                    if not self._is_stop():
                        self._sleep()
            except ConfigurationException:
                logging.exception("Exiting due to a configuration issue.")
                break
            except Exception:
                logging.exception("Failed to connect to to ws api.")
                self._sleep()

    def _sleep(self):
        logging.info(f"Reconnecting after {self._get_backoff()} sec")
        time.sleep(self._get_backoff())
        if self._get_backoff() < 120:
            self._set_backoff(self._get_backoff() * 2)  # simple exponential backoff

    def _ident(self) -> str:
        payload: list[dict[str, Any]] = list()

        for endpoint in self._name_by_endpoint:
            name = self._name_by_endpoint[endpoint]
            ident_item = {
                    "name": name,
                    "vendor": self._vendor,
                    "version": self._version,
                    "isFda": self._is_fda,
                    "endpoint": endpoint,
                    "operation": self._operation.name,
                    "mode": self._mode.name,
                    "source": self._source.name
            }
            _add_field_if_exists("description", self._description, ident_item)
            _add_field_if_exists("icon", self._icon, ident_item)
            _add_field_if_exists("input", self._input_name, ident_item)
            _add_field_if_exists("inputParameters", self._input_parameters, ident_item)

            payload.append(ident_item)
        message = {
            "message": "ident",
            "payload": payload
        }
        return json.dumps(message)

    def _create_roles_anywhere_session_credentials(self) -> Credentials:
        auth = json.loads(base64.b64decode(self._auth_string.encode('utf-8')).decode('utf-8'))
        readonly_credentials = IAMRolesAnywhereSession(
            profile_arn=auth['profile_arn'],
            role_arn=auth['role_arn'],
            trust_anchor_arn=auth['trust_anchor_arn'],
            certificate=bytes(auth['certificate'], 'utf8'),
            private_key=bytes(auth['privkey'], 'utf8'),
            region=auth['region']
        ).get_refreshable_credentials().get_frozen_credentials()
        return Credentials(
            access_key=readonly_credentials.access_key,
            secret_key=readonly_credentials.secret_key,
            token=readonly_credentials.token
        )

    def _create_assumed_role_session_credentials(self, plugin_role_arn: str) -> Credentials:
        client = boto3.client('sts')
        response = client.assume_role(
            RoleArn=plugin_role_arn,
            RoleSessionName=f'plugin-api-{self._vendor}'
        )
        creds_dict = response['Credentials']
        creds = Credentials(
            access_key=creds_dict['AccessKeyId'],
            secret_key=creds_dict['SecretAccessKey'],
            token=creds_dict['SessionToken']
        )
        return creds

    def _create_session(self) -> Credentials:
        if 'PLUGIN_ROLE_ARN' in os.environ:
            return self._create_assumed_role_session_credentials(os.environ['PLUGIN_ROLE_ARN'])
        elif self._auth_string:
            logging.info('Authenticating based on auth string')
            return self._create_roles_anywhere_session_credentials()
        else:
            raise ConfigurationException('Either env variable PLUGIN_ROLE_ARN should be specified or auth_string should be specified!')

    def _get_signed_connect_url(self) -> str:
        credentials = self._create_session()
        query_string = f'?type=plugin&vendor={self._vendor}'
        request = AWSRequest(
            method="GET",
            url=f"wss://{self._server}{query_string}"
        )
        logging.info(f'request: {request}')
        # Sign the request
        SigV4QueryAuth(credentials, "execute-api", self._server_region).add_auth(request)

        logging.info(f'Connect url: {request.url}')
        # return the signed url
        return request.url

    def _get_backoff(self) -> int:
        with self._lock:
            return self._backoff

    def _set_backoff(self, backoff: int) -> None:
        with self._lock:
            self._backoff = backoff

    def _get_resend_ident(self) -> bool:
        with self._lock:
            return self._resend_ident

    def _set_resend_ident(self, resend: bool) -> None:
        with self._lock:
            self._resend_ident = resend

    def _set_stop(self) -> None:
        with self._lock:
            self._stop = True

    def _is_stop(self) -> bool:
        with self._lock:
            return self._stop
