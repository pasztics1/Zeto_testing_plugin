from enum import Enum, auto


class CaptureStatus(Enum):
    @classmethod
    def get_from_name(cls, value):
        for m, mm in CaptureStatus.__members__.items():
            if m == value:
                return mm
        raise ValueError(f'CaptureStatus unknown: {value}')

    DONNING = auto()
    RECORDING = auto()
    RECORDED = auto()
    INTERPRETED = auto()
    CLOSED = auto()
    FEEDBACK = auto()
    UPLOADING = auto()
    UPLOADED = auto()
    IMPORTING = auto()
    IMPORTED = auto()
    ERROR = auto()
    SCHEDULED = auto()
