from enum import Enum, auto


class Source(Enum):
    original = auto()
    processed = auto()
