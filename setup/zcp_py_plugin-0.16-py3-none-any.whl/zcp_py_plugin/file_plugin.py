from __future__ import annotations

import json
import logging
from typing import final, Optional, Mapping
from abc import abstractmethod
from tempfile import NamedTemporaryFile, mkdtemp
import requests
import os
import mimetypes
import shutil
from contextlib import contextmanager

from zcp_py_plugin.plugin import Plugin
from zcp_py_plugin.plugin_result_type import PluginResultType
from zcp_py_plugin.request import Request
from zcp_py_plugin.marker_format import MarkerFormat
from zcp_py_plugin.plugin_json_encoder import PluginJSONEncoder
from zcp_py_plugin.transformparameters import TransformParameters

DEFAULT_LIMIT = 100000


@contextmanager
def tempdir():
    path = mkdtemp()
    try:
        yield path
    finally:
        try:
            shutil.rmtree(path)
        except IOError:
            logging.error(f'Failed to clean up temp dir {path}')


class FilePlugin(Plugin):
    def __init__(self, vendor: str, name_by_endpoint: Mapping[str, str], request: Request):
        super().__init__(vendor, name_by_endpoint, request)
        self.percent = None
        self.message = None
        self._temp_dir = None

    @final
    def do(self):
        with tempdir() as temp_dir:
            self._temp_dir = temp_dir
            self.go()

    @abstractmethod
    def go(self) -> None:
        """ This is called by the PluginClient in the beginning.
        This is run on a separate thread
        """
        pass

    @final
    def _get_file(self, url: str) -> str:
        source_file = NamedTemporaryFile(delete=False, dir=self._temp_dir)
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(source_file.name, 'wb') as f:
                for chunk in r.iter_content(chunk_size=128):
                    f.write(chunk)
        return source_file.name

    @final
    def _get_source(self, file_format: Optional[str] = None, transform: str | TransformParameters = TransformParameters.DC_BASELINE_CORRECTION) -> str:
        transform_parameters = transform.parameters if isinstance(transform, TransformParameters) else transform
        url = (f"{self.request.source}"
               f"{'&format='+file_format if file_format else ''}"
               f"&transform={transform_parameters}")
        return self._get_file(url)

    @final
    def _get_marker(self, marker_format: MarkerFormat, user: bool, io: bool, limit: int, system: bool) -> str:
        url = (f"{self.request.marker}"
               f"&limit={limit}"
               f"&user={str(user).lower()}"
               f"&system={str(system).lower()}"
               f"&io={str(io).lower()}"
               f"&format={marker_format.name.lower()}"
               )
        return self._get_file(url)

    def get_edf_file(self, transform: str | TransformParameters = TransformParameters.DC_BASELINE_CORRECTION) -> str:
        return self._get_source('edf', transform)

    def get_eeg_file(self, transform: str | TransformParameters = TransformParameters.DC_BASELINE_CORRECTION) -> str:
        return self._get_source(None, transform)

    def get_marker_file(self, user=True, io=True, system=True, limit=DEFAULT_LIMIT) -> str:
        return self.get_marker_file_zmrk(user, io, system, limit)

    def get_meta_file(self) -> str:
        source_file = NamedTemporaryFile(delete=False, dir=self._temp_dir)
        with open(source_file.name, 'w') as f:
            json.dump(self.request.meta, f, cls=PluginJSONEncoder, indent=2)
        return source_file.name

    def get_marker_file_zmrk(self, user=True, io=True, system=True, limit=DEFAULT_LIMIT) -> str:
        return self._get_marker(
            marker_format=MarkerFormat.ZMRK,
            user=user,
            io=io,
            system=system,
            limit=limit
        )

    def get_marker_file_csv(self, user=True, io=True, system=True, limit=DEFAULT_LIMIT) -> str:
        return self._get_marker(
            marker_format=MarkerFormat.CSV,
            user=user,
            io=io,
            system=system,
            limit=limit
        )

    def get_marker_file_json(self, user=True, io=True, system=True, limit=DEFAULT_LIMIT) -> str:
        return self._get_marker(
            marker_format=MarkerFormat.JSON,
            user=user,
            io=io,
            system=system,
            limit=limit
        )

    def get_logo_file(self) -> Optional[str]:
        if self.request.meta.organization_logo:
            return self._get_file(self.request.meta.organization_logo)
        else:
            return None

    @final
    def progress(self, percent: int, message: Optional[str] = None):
        if percent < 0 or percent > 100:
            raise ValueError(f"{percent} is not a real percentage")
        if self.percent != percent or (message and message != self.message):
            self.percent = percent
            self.message = message if message else self.message
            status = 'OK' if self.percent == 100 else 'RUNNING'
            json_object = {
                    "status": status,
                    "progressPercent": self.percent
            }
            if self.message:
                json_object["message"] = self.message
            logging.info(f"Sending status: {json.dumps(json_object)}")
            response = requests.post(
                url=self.request.progress,
                json=json_object
            )
            response.raise_for_status()

    @final
    def emit(self, result_type: PluginResultType, file_name: str, endpoint: Optional[str] = None) -> None:
        _endpoint = endpoint if endpoint else next(iter(self.name_by_endpoint.keys()))
        url = f'{self.request.target_base}/{result_type.name.lower()}/{self.vendor}/{_endpoint}?context={self.request.target_context}'
        with open(file_name, 'rb') as f:
            multiple_files = [
                ('results', (os.path.basename(file_name), f, mimetypes.guess_type(file_name)))
            ]
            response = requests.post(url, files=multiple_files, stream=True)
            response.raise_for_status()

    def warnings(self, warnings: str | list[str]) -> None:
        warnings_list = warnings if isinstance(warnings, list) else [warnings]
        json_object = {
            "warnings": warnings_list
        }
        logging.info(f"Sending warnings: {json.dumps(json_object)}")
        response = requests.post(
            url=self.request.warnings,
            json=json_object
        )
        response.raise_for_status()
