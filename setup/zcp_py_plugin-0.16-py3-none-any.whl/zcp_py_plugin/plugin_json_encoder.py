from __future__ import annotations

import json
from dataclasses import is_dataclass, asdict
from enum import Enum


class PluginJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if is_dataclass(o):
            return asdict(o)
        if isinstance(o, Enum):
            return o.name
        return super().default(o)
