from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Optional, Self, Any

from zcp_py_plugin.meta import Meta


class RequestBuilder:
    def __init__(self):
        super().__init__()
        self._source: Optional[str] = None
        self._marker: Optional[str] = None
        self._target_base: Optional[str] = None
        self._target_context: Optional[str] = None
        self._warnings: Optional[str] = None
        self._progress: Optional[str] = None
        self._phi: Optional[str] = None
        self._meta: Optional[Meta] = None

    def message(self, message: str) -> Self:
        json_str = message if message.startswith('{') else base64.b64decode(message.encode('utf-8')).decode('utf-8')
        return self.from_dict(json.loads(json_str))

    def from_dict(self, dict_object: dict[str, Any]) -> Self:
        return self.source(dict_object['source']) \
            .marker(dict_object['marker']) \
            .target_base(dict_object['targetBase']) \
            .target_context(dict_object['targetContext']) \
            .warnings(dict_object['warnings']) \
            .progress(dict_object['progress']) \
            .phi(dict_object.get('phi')) \
            .meta(Meta.of().from_dict(dict_object['meta']).build())

    def source(self, source: str) -> Self:
        self._source = source
        return self

    def marker(self, marker: str) -> Self:
        self._marker = marker
        return self

    def target_base(self, target_base: str) -> Self:
        self._target_base = target_base
        return self

    def target_context(self, target_context: str) -> Self:
        self._target_context = target_context
        return self

    def warnings(self, warnings: str) -> Self:
        self._warnings = warnings
        return self

    def progress(self, progress: str) -> Self:
        self._progress = progress
        return self

    def phi(self, phi: Optional[str]) -> Self:
        self._phi = phi
        return self

    def meta(self, meta: Meta) -> Self:
        self._meta = meta
        return self

    def build(self) -> Request:
        if not self._source:
            raise ValueError('Source is mandatory for Request')
        if not self._marker:
            raise ValueError('Marker is mandatory for Request')
        if not self._target_base:
            raise ValueError('Target base is mandatory for Request')
        if not self._target_context:
            raise ValueError('Target context is mandatory for Request')
        if not self._meta:
            raise ValueError('Meta is mandatory for Request')
        if not self._warnings:
            raise ValueError('Warnings is mandatory for Request')

        return Request(
            meta=self._meta,
            source=self._source,
            marker=self._marker,
            target_base=self._target_base,
            target_context=self._target_context,
            warnings=self._warnings,
            progress=self._progress,
            phi=self._phi,
        )


@dataclass(frozen=True)
class Request:
    meta: Meta
    source: str
    marker: str
    target_base: str
    target_context: str
    warnings: str
    progress: Optional[str]
    phi: Optional[str]

    @classmethod
    def of(cls) -> RequestBuilder:
        return RequestBuilder()
