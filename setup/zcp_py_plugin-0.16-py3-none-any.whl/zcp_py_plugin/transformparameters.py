from __future__ import annotations

from enum import Enum


class TransformParameters(Enum):
    def __init__(self, parameters: str):
        self.parameters = parameters

    CASUAL_DC_REMOVAL_0_5_HZ = 'dcremove:0.5'
    ZERO_PHASE_DC_0_1 = 'dcremove:0.5%20frf:on%20hpf:0.1'
    DC_BASELINE_CORRECTION = 'dcremove:0.5%20frf:on'
